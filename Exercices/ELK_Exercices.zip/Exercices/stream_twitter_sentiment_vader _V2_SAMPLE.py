
import json
import tweepy
from elasticsearch import Elasticsearch
from datetime import datetime, timedelta
from vaderSentiment_fr.vaderSentiment import SentimentIntensityAnalyzer
from datetime import timezone

# Clefs Twitter
ckey=""
csecret=""
atoken=""
asecret=""

# Création de la connexion vers Elasticsearch
es = Elasticsearch("http://localhost:9200")
#es = Elasticsearch(['https://localhost:9202'],basic_auth=('elastic','1QFb9qd5_M==NXvJONxq'), verify_certs=None)

SIA = SentimentIntensityAnalyzer()

# Liste de recherche
On_watch = ["nantes","Nantes","Raoult","Macron","Ukraine","Russie","Niort","Paris"]

# Subclass Stream to print IDs of Tweets received
class IDPrinter(tweepy.Stream):
    def test_none_value(self, str, default):
        if str is None:
            return default
        else:
            return str

    def on_data(self, data):
        #print(data)
        # Découpage du tweet
        dict_data = json.loads(data)
        # Test de présence de datas
        try:
            vUserScreenName=self.test_none_value(dict_data["user"]["screen_name"],"No Screen Name")
            vUserLocation=self.test_none_value(dict_data["user"]["location"],"No Location")
            vfollowers_count=self.test_none_value(dict_data["user"]["followers_count"],0)
            vfriends_count=self.test_none_value(dict_data["user"]["friends_count"],0)
            vgeo_enabled=self.test_none_value(dict_data["user"]["geo_enabled"],"No GPS")
            vlang=self.test_none_value(dict_data["user"]["lang"],"No Language")
            vText=self.test_none_value(dict_data["text"],"No Text")
            # Analyse du sentiment
            score = SIA.polarity_scores(vText)
            print(score)
            vSource=self.test_none_value(dict_data["source"],"No Source")
            # Récupération du score agrégé
            if score['compound'] >= 0.05 : 
                sentiment = "Positif"
            elif score['compound'] <= - 0.05 : 
                sentiment = "Négatif"
            else : 
                sentiment = "Neutre"
        except:
            vUserScreenName=""
            vUserLocation=""
            vfollowers_count=""
            vfriends_count=""
            vgeo_enabled=""
            vlang=""
            vText=""
            vSource=""

        # Initialisation
        vMatch = []
        count = 0

        # Check si un des termes recherchés est dans la liste et update de la liste vMatch
        # On ne cherche que dans le message (text) du tweet
        for term in On_watch:
            if vText.find((term))>0:
                vMatch.append((term))

                # Incrémentation occurences
                count += 1

        # Ecriture de la donnée dans Elasticsearch uniquement si au moins un des termes recherchés est dans la liste
        if count > 0:
            print(vUserScreenName+' : '+vUserLocation)
            vCreatedAt=datetime.now(timezone.utc) # En UTC dans Elasticsearch!
            print('######################################################################################')

            vbody={"User_Screen_Name":vUserScreenName,
                   "User_Location":vUserLocation,
                   "User_Follower_Count":vfollowers_count,
                   "User_Friend_Count":vfriends_count,
                   "Geo_Enabled":vgeo_enabled,
                   "Message":vText,
                   "Language":vlang,
                   "Source":vSource,
                   "Date":vCreatedAt,
                   "Matchs":'/'.join(vMatch),
                   #"polarity": vSentimentTweet.polarity#,
                   #"subjectivity": vSentimentTweet.subjectivity,
                   "sentiment": sentiment
                   }
            res = es.index(index="twitter_sentiment", body=vbody)
            print(res)
            print('########################################################""')
            print('/'.join(vMatch))
            return(True)

        # Si le Tweet remonté ne contient pas les termes recherchés ou en contient dans un autre champs que dans le message du Tweet on ne le prend pas en compte
        else:
            pass

    def on_error(self, status):
        print(status)
        

# Initialize instance of the subclass
printer = IDPrinter(ckey, csecret, atoken, asecret)

# Filter realtime Tweets by keyword
printer.filter(track=On_watch)
