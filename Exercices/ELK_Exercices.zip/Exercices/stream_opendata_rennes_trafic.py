# Librairies
import requests
from elasticsearch import Elasticsearch
import time
import json
import datetime
# from elasticsearch.connection import create_ssl_context
import ssl
from datetime import timezone
import pytz

#################################################################################################################################################################
# Variables
nb_rows=1000
indice_confiance=50
api_endpoint="https://data.rennesmetropole.fr/api/records/1.0/search/?dataset=etat-du-trafic-en-temps-reel&q=&rows=" + str(nb_rows) + "&facet=denomination"
# Informations de connexion à Elasticsearch (en mode non sécurisé)
es_host="localhost"
es_port="9200"
# Autres variables
index_name="rennes_trafic"
sleep_time=180 # Temps en seconde avant de réinterroger l'API
# Transcodifications
# https://data.rennesmetropole.fr/explore/dataset/etat-du-trafic-en-temps-reel/information/
status = {
    "unknown": "état inconnu",
    "freeFlow": "fluide",
    "heavy": "chargé",
    "congested":"congestionné",
    "impossible":"circulation impossible"
}
#################################################################################################################################################################

def es_Connect():
    #es = Elasticsearch("http://localhost:9200")
    es = Elasticsearch(['https://localhost:9202'],basic_auth=('elastic','1QFb9qd5_M==NXvJONxq'), verify_certs=None)
    print(es.info())
    return es

def main():
    # Connexion à Elasticsearch
    es = es_Connect()
    while (1<2):
        # Requête API
        r = requests.get(api_endpoint)
        binary = r.content
        output = json.loads(binary)
        for record in output['records']:
            # Si la ligne n'est pas géolocalisable (avec le champ geo_point_2d), on passe la ligne
            try:
                # Inversion des coordonnées GPS
                record['fields']['geo_point_2d'] = record['fields']['geo_point_2d'][::-1]
                # Application de la transcodification
                #print(record['fields'])
                for key in status.keys():
                    if key==record['fields']['trafficstatus']:
                        record['fields']['trafficstatus']=status[key]
                #print(record['fields'])
                print("############################################################################################")
                v_orig_date=record['fields']['datetime']
                dt_created=datetime.datetime.fromisoformat(v_orig_date).astimezone(pytz.UTC)
                record['fields']['datetime']=v_orig_date
                print(dt_created)
                # On n'indexe que les lignes qui ont un indice de confiance supérieur à 50%
                if int(record['fields']['traveltimereliability']) >= indice_confiance:
                    es.index(index=index_name, ignore=400, body=record['fields'])
                    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")," -> Document inséré")
                else:
                    print(" -> Mesure pas assez précise")
            except:
                print(" -> Document non géolocalisable")
        # On attend un peu avant d'aller à nouveau chercher un document sur l'API
        time.sleep(sleep_time)

if __name__ == "__main__":
    main()